# StreamTube TV — Android TV 32-bit alpha

An **independent native Android TV proof of concept**, informed by the feature goals of
[Stream-Tube-Desktop](https://github.com/Avaneesh-Inamdar/Stream-Tube-Desktop).
This is **not a Rust/GPUI port**: the original desktop project has no Android build target.
Do not represent this prototype as an official upstream app or as feature-equivalent.

## Included
- TV launcher entry, large focusable controls, remote (D-pad / Select / Back)
- Trending and YouTube search through public Piped endpoints, with instance fallback
- Direct media playback using Android VideoView (prefers merged H.264 MP4 <= 720p)
- Left/right seek 10 seconds; OK pause/resume
- SponsorBlock automatic skip for sponsor category (community API, if reachable)
- Open video in installed YouTube app when the direct stream is not available
- Dynamic thumbnails with bounded in-memory cache
- No native libraries: compatible with 32-bit `armeabi-v7a` TVs running Android 7+

## Not in this version
- Original desktop GPUI interface, desktop Rust extraction backend, libmpv
- Google sign-in, subscriptions/history sync, DeArrow, downloads, 1080p+ DASH with separate audio
- Guaranteed no-ads playback on all videos

This app depends on community Piped servers and on public YouTube stream availability;
these may fail or change without warning. Playback is **not device-tested**.

## Build

Use GitHub Actions `android-tv-apk.yml`, or Android SDK 35 + JDK 17 + Gradle 8.10.2:

    gradle :app:assembleDebug

APK: `app/build/outputs/apk/debug/app-debug.apk`

Install using ADB:

    adb install -r app/build/outputs/apk/debug/app-debug.apk

No native `.so` files are included, so ABI does not restrict installation.
This is a signed debug APK suitable for side-loading/testing, **not** a production release.

### Attribution
Stream-Tube-Desktop © Avaneesh Inamdar and contributors, MIT license.
The code in this prototype is a new Android implementation, not an upstream release.
