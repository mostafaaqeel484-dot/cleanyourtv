package tv.streamtube.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android-native, TV-focused prototype; no webview and no AndroidX dependency. */
public class MainActivity extends Activity {
    private final ExecutorService work = Executors.newFixedThreadPool(2);
    private final ArrayList<Entry> items = new ArrayList<>();
    private GridView grid;
    private TextView status;
    private EditText search;
    private VideoAdapter adapter;
    private TextView retry;
    private TextView openYouTube;
    private TextView configure;
    private String previousTerm = null;
    private int serial = 0;

    static final class Entry {
        final String title, creator, thumb, id;
        Entry(String title, String creator, String thumb, String id) {
            this.title = title; this.creator = creator; this.thumb = thumb; this.id = id;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(1024, 1024); // Fullscreen for TV
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        Api.setCustomServer(getPreferences(MODE_PRIVATE).getString("server", ""));
        makeUI();
        load(null);
    }

    private void makeUI() {
        LinearLayout page = new LinearLayout(this);
        page.setBackgroundColor(Style.BACK);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(Style.dp(this, 33), Style.dp(this, 20), Style.dp(this, 33), Style.dp(this, 15));
        setContentView(page);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(top, new LinearLayout.LayoutParams(-1, Style.dp(this, 62)));

        TextView brand = Style.text(this, "▶  STREAM TUBE  TV", 28, Style.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1.25f));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("ابحث عن فيديو أو قناة...");
        search.setHintTextColor(Style.MUTED);
        search.setTextColor(Color.WHITE);
        search.setTextSize(19);
        search.setBackground(Style.rounded(Style.CARD, 12, this));
        search.setPadding(Style.dp(this, 17), 0, Style.dp(this, 17), 0);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load(search.getText().toString().trim()); return true;
            }
            return false;
        });
        top.addView(search, new LinearLayout.LayoutParams(0, Style.dp(this, 46), 1.35f));
        TextView submit = Style.button(this, "بحث");
        LinearLayout.LayoutParams sb = new LinearLayout.LayoutParams(-2, Style.dp(this, 46));
        sb.leftMargin = Style.dp(this, 12);
        top.addView(submit, sb);
        submit.setOnClickListener(v -> load(search.getText().toString().trim()));

        LinearLayout topics = new LinearLayout(this);
        topics.setOrientation(LinearLayout.HORIZONTAL);
        topics.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams topicLp = new LinearLayout.LayoutParams(-1, Style.dp(this, 64));
        page.addView(topics, topicLp);
        addTopic(topics, "الرائج", null);
        addTopic(topics, "رياضة", "sports highlights");
        addTopic(topics, "ألعاب", "gaming");
        addTopic(topics, "موسيقى", "music");
        addTopic(topics, "تقنية", "technology");

        status = Style.text(this, "جاري تحميل الفيديوهات...", 16, Style.MUTED, false);
        status.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(status, new LinearLayout.LayoutParams(-1, Style.dp(this, 40)));

        LinearLayout errorActions = new LinearLayout(this);
        errorActions.setGravity(Gravity.CENTER_VERTICAL);
        errorActions.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(errorActions, new LinearLayout.LayoutParams(-1, Style.dp(this, 55)));
        retry = Style.button(this, "إعادة المحاولة");
        openYouTube = Style.button(this, "بحث عبر YouTube");
        configure = Style.button(this, "إعداد خادم API");
        for (TextView action : new TextView[]{retry, openYouTube, configure}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, Style.dp(this, 42));
            p.rightMargin = Style.dp(this, 12);
            errorActions.addView(action, p);
        }
        retry.setOnClickListener(v -> load(previousTerm));
        openYouTube.setOnClickListener(v -> youtubeSearch(previousTerm));
        configure.setOnClickListener(v -> configureServer());
        showErrorActions(false);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(Style.dp(this, 16));
        grid.setVerticalSpacing(Style.dp(this, 20));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setClipToPadding(false);
        grid.setPadding(Style.dp(this, 3), Style.dp(this, 5), Style.dp(this, 3), Style.dp(this, 25));
        grid.setVerticalScrollBarEnabled(false);
        grid.setFocusable(true);
        adapter = new VideoAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= items.size()) return;
            Entry entry = items.get(position);
            if (entry.id.isEmpty()) return;
            Intent i = new Intent(this, PlayerActivity.class);
            i.putExtra("videoId", entry.id);
            i.putExtra("videoTitle", entry.title);
            startActivity(i);
        });
        page.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));
    }

    private void addTopic(LinearLayout row, String name, String term) {
        TextView b = Style.button(this, name);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, Style.dp(this, 43));
        p.rightMargin = Style.dp(this, 14);
        row.addView(b, p);
        b.setOnClickListener(v -> {
            if (term != null) search.setText(term);
            load(term);
        });
    }

    private void showErrorActions(boolean show) {
        int v = show ? View.VISIBLE : View.GONE;
        retry.setVisibility(v);
        openYouTube.setVisibility(v);
        configure.setVisibility(v);
    }

    private void youtubeSearch(String term) {
        String query = term == null || term.trim().isEmpty() ? "" : term.trim();
        Uri link = Uri.parse(query.isEmpty() ? "https://www.youtube.com/" :
             "https://www.youtube.com/results?search_query=" + Uri.encode(query));
        try { startActivity(new Intent(Intent.ACTION_VIEW, link)); }
        catch (ActivityNotFoundException ex) { status.setText("لا يوجد تطبيق YouTube أو متصفح على الجهاز."); }
    }

    private void configureServer() {
        EditText field = new EditText(this);
        field.setSingleLine();
        field.setHint("https://your-invidious-instance.com");
        field.setText(Api.customServer());
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(Style.dp(this, 18), Style.dp(this, 8), Style.dp(this, 18), 0);
        wrapper.addView(field, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
            .setTitle("خادم API مخصص (Piped أو Invidious)")
            .setMessage("اختياري. احذف الرابط للرجوع إلى الخوادم العامة. لا تُدخل حسابك أو كلمات السر.")
            .setView(wrapper)
            .setPositiveButton("حفظ وتجربة", (dialog, which) -> {
                try {
                    Api.setCustomServer(field.getText().toString());
                    getPreferences(MODE_PRIVATE).edit().putString("server", Api.customServer()).apply();
                    load(previousTerm);
                } catch (Exception error) {
                    status.setText(error.getMessage());
                    showErrorActions(true);
                }
            }).setNegativeButton("إلغاء", null).show();
    }

    private void load(String term) {
        final int request = ++serial;
        previousTerm = term;
        showErrorActions(false);
        final boolean isSearch = term != null && !term.trim().isEmpty();
        status.setText(isSearch ? "جاري البحث عن: " + term : "جاري تحميل الفيديوهات الرائجة...");
        work.execute(() -> {
            try {
                JSONArray data = isSearch ? Api.search(term.trim()) : Api.trending();
                ArrayList<Entry> result = new ArrayList<>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject item = data.optJSONObject(i);
                    if (item == null) continue;
                    String id = item.optString("videoId", "");
                    if (!id.matches("[A-Za-z0-9_-]{11}")) id = Api.idFromUrl(item.optString("url", ""));
                    if (id.isEmpty()) continue;
                    String title = item.optString("title", "Video");
                    String creator = item.optString("uploaderName", item.optString("uploader", ""));
                    String thumbnail = item.optString("thumbnailUrl", "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg");
                    result.add(new Entry(title, creator, thumbnail, id));
                }
                runOnUiThread(() -> {
                    if (request != serial || isFinishing()) return;
                    items.clear(); items.addAll(result); adapter.notifyDataSetChanged();
                    status.setText(result.isEmpty() ? "لا توجد نتائج. جرّب بحثاً آخر." : (isSearch ? "نتائج البحث" : "الأكثر رواجاً") + "  •  " + result.size() + " فيديو • " + Api.provider());
                    showErrorActions(result.isEmpty());
                    if (!items.isEmpty()) grid.requestFocus();
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    if (request != serial || isFinishing()) return;
                    items.clear(); adapter.notifyDataSetChanged();
                    String reason = Api.lastError();
                    if (reason.length() > 200) reason = reason.substring(0, 200) + "...";
                    status.setText("تعذّر جلب البيانات من الخوادم: " + reason);
                    showErrorActions(true);
                });
            }
        });
    }

    final class VideoAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int pos) { return items.get(pos); }
        @Override public long getItemId(int pos) { return pos; }
        @Override public View getView(int pos, View old, android.view.ViewGroup parent) {
            Entry e = items.get(pos);
            LinearLayout card = new LinearLayout(MainActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Style.focused(MainActivity.this));
            card.setPadding(Style.dp(MainActivity.this, 6), Style.dp(MainActivity.this, 6), Style.dp(MainActivity.this, 6), Style.dp(MainActivity.this, 10));
            card.setFocusable(true);
            card.setClickable(true);
            card.setOnClickListener(v -> grid.performItemClick(card, pos, getItemId(pos)));
            card.setOnFocusChangeListener((v, focused) -> v.animate().scaleX(focused ? 1.035f : 1f).scaleY(focused ? 1.035f : 1f).setDuration(125).start());
            ImageView img = new ImageView(MainActivity.this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackground(Style.rounded(0xFF202531, 8, MainActivity.this));
            card.addView(img, new LinearLayout.LayoutParams(-1, Style.dp(MainActivity.this, 125)));
            Thumbnails.bind(img, e.thumb);
            TextView title = Style.text(MainActivity.this, e.title, 15, Style.WHITE, true);
            title.setMaxLines(2); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, Style.dp(MainActivity.this, 50));
            tl.topMargin = Style.dp(MainActivity.this, 8);
            card.addView(title, tl);
            TextView channel = Style.text(MainActivity.this, e.creator, 13, Style.MUTED, false);
            channel.setSingleLine(true); channel.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.addView(channel, new LinearLayout.LayoutParams(-1, Style.dp(MainActivity.this, 24)));
            return card;
        }
    }

    @Override protected void onDestroy() {
        ++serial;
        work.shutdownNow();
        super.onDestroy();
    }
}
