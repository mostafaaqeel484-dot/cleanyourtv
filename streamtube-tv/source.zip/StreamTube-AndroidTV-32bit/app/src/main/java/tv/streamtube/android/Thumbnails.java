package tv.streamtube.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class Thumbnails {
    private static final ExecutorService pool = Executors.newFixedThreadPool(3);
    private static final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(10 * 1024) {
        protected int sizeOf(String key, Bitmap value) { return value.getByteCount()/1024; }
    };
    static void bind(ImageView view, String url) {
        view.setImageDrawable(null);
        view.setTag(url);
        if (url == null || !url.startsWith("https://")) return;
        Bitmap cached = cache.get(url);
        if (cached != null) { view.setImageBitmap(cached); return; }
        pool.submit(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(9000);
                connection.setInstanceFollowRedirects(true);
                if (connection.getResponseCode() != 200) return;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                Bitmap b;
                try (java.io.InputStream in = connection.getInputStream()) {
                    b = BitmapFactory.decodeStream(in, null, o);
                }
                if (b != null) {
                    cache.put(url, b);
                    view.post(() -> {
                        if (url.equals(view.getTag())) view.setImageBitmap(b);
                    });
                }
            } catch (Exception ignored) { }
            finally { if (connection != null) connection.disconnect(); }
        });
    }
}
