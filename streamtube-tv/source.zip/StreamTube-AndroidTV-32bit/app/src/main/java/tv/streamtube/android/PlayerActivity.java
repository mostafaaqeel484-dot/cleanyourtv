package tv.streamtube.android;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 32-bit-compatible Android MediaPlayer playback. Direct merged streams only in this alpha. */
public class PlayerActivity extends Activity {
    private final ExecutorService network = Executors.newFixedThreadPool(2);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ArrayList<Segment> segments = new ArrayList<>();
    private VideoView player;
    private TextView info;
    private TextView fallback;
    private String videoId;
    private boolean ready = false;
    private boolean disposed = false;

    private static final class Segment {
        long begin, end;
        boolean skipped;
        Segment(long begin, long end) { this.begin=begin; this.end=end; }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (disposed) return;
            if (ready && player != null && player.isPlaying()) {
                long p = player.getCurrentPosition();
                synchronized (segments) {
                    for (Segment segment : segments) {
                        if (!segment.skipped && p >= segment.begin && p < segment.end - 150) {
                            segment.skipped = true;
                            player.seekTo((int) segment.end);
                            info.setText("SponsorBlock: تم تجاوز الفقرة الإعلانية");
                            info.setVisibility(View.VISIBLE);
                            ui.postDelayed(() -> { if (!disposed && ready) info.setVisibility(View.GONE); }, 1800);
                            break;
                        }
                    }
                }
            }
            ui.postDelayed(this, 850);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(1024, 1024);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        videoId = getIntent().getStringExtra("videoId");
        if (videoId == null || !videoId.matches("[A-Za-z0-9_-]{11}")) { finish(); return; }
        makeUI(getIntent().getStringExtra("videoTitle"));
        loadVideo();
        loadSponsors();
    }

    private void makeUI(String title) {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        player = new VideoView(this);
        player.setFocusable(true);
        FrameLayout.LayoutParams pv = new FrameLayout.LayoutParams(-1, -1);
        pv.gravity = Gravity.CENTER;
        root.addView(player, pv);
        player.setOnPreparedListener(mp -> {
            if (disposed) return;
            ready = true;
            fallback.setVisibility(View.GONE);
            info.setVisibility(View.GONE);
            mp.setOnInfoListener((m, what, extra) -> false);
            player.start();
            player.requestFocus();
            ui.post(tick);
        });
        player.setOnErrorListener((mp, what, extra) -> {
            showError("تعذر تشغيل هذه النسخة من الفيديو (" + what + ").");
            return true;
        });
        player.setOnCompletionListener(mp -> { info.setText("انتهى الفيديو — اضغط رجوع"); info.setVisibility(View.VISIBLE); });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(0xAA10131B);
        header.setPadding(Style.dp(this, 25), Style.dp(this, 12), Style.dp(this, 25), Style.dp(this, 12));
        TextView videoTitle = Style.text(this, title == null ? "StreamTube TV" : title, 21, Style.WHITE, true);
        videoTitle.setMaxLines(1);
        header.addView(videoTitle);
        TextView hint = Style.text(this, "◀ ▶ تقديم/ترجيع 10 ثوانٍ     OK تشغيل/إيقاف     Back رجوع", 14, Style.MUTED, false);
        header.addView(hint);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(header, hp);

        LinearLayout overlay = new LinearLayout(this);
        overlay.setGravity(Gravity.CENTER);
        overlay.setPadding(Style.dp(this, 25), Style.dp(this, 15), Style.dp(this, 25), Style.dp(this, 15));
        overlay.setOrientation(LinearLayout.VERTICAL);
        info = Style.text(this, "يتم جلب رابط الفيديو...", 19, Style.WHITE, true);
        info.setGravity(Gravity.CENTER);
        overlay.addView(info);
        fallback = Style.button(this, "فتح في تطبيق YouTube");
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(-2, -2);
        b.topMargin = Style.dp(this, 18);
        overlay.addView(fallback, b);
        fallback.setVisibility(View.GONE);
        fallback.setOnClickListener(v -> openYouTube());
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        root.addView(overlay, op);
    }

    private void loadVideo() {
        network.submit(() -> {
            try {
                JSONObject json = Api.streams(videoId);
                String best = chooseStream(json);
                if (best == null) throw new Exception("No compatible muxed MP4/HLS stream available");
                runOnUiThread(() -> {
                    if (disposed) return;
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 14; TV) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
                    player.setVideoURI(Uri.parse(best), headers);
                    player.requestFocus();
                });
            } catch (Exception e) {
                runOnUiThread(() -> showError("لم أتمكن من جلب بث متوافق. جرّب فتحه في YouTube."));
            }
        });
    }

    static String chooseStream(JSONObject json) {
        JSONArray streams = json.optJSONArray("videoStreams");
        String best = null;
        int score = -1;
        if (streams != null) {
            for (int i=0; i<streams.length(); i++) {
                JSONObject s = streams.optJSONObject(i);
                if (s == null || s.optBoolean("videoOnly", true)) continue;
                String type = s.optString("mimeType", "");
                String codec = s.optString("codec", "");
                String url = s.optString("url", "");
                int height = s.optInt("height", 0);
                if (!url.startsWith("https://") || !type.contains("mp4")) continue;
                if (height > 720 || height < 144) continue;
                int n = height + ((codec.contains("avc") || codec.contains("h264")) ? 10000 : 0);
                if (n > score) { score = n; best = url; }
            }
        }
        if (best != null) return best;
        String hls = json.optString("hls", "");
        return hls.startsWith("https://") ? hls : null;
    }

    private void loadSponsors() {
        network.submit(() -> {
            try {
                JSONArray data = Api.sponsors(videoId);
                synchronized (segments) {
                    segments.clear();
                    for (int i=0; i<data.length(); i++) {
                        JSONObject e = data.optJSONObject(i);
                        if (e == null || !"skip".equals(e.optString("actionType"))) continue;
                        JSONArray times = e.optJSONArray("segment");
                        if (times == null || times.length()<2) continue;
                        long s = (long)(times.optDouble(0)*1000);
                        long f = (long)(times.optDouble(1)*1000);
                        if (f > s) segments.add(new Segment(s, f));
                    }
                }
            } catch (Exception ignored) { }
        });
    }

    private void showError(String message) {
        if (disposed) return;
        ready = false;
        info.setText(message);
        info.setVisibility(View.VISIBLE);
        fallback.setVisibility(View.VISIBLE);
        fallback.requestFocus();
    }

    private void openYouTube() {
        Uri u = Uri.parse("https://www.youtube.com/watch?v=" + videoId);
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
        catch (ActivityNotFoundException e) {
            info.setText("لا يوجد تطبيق يفتح روابط YouTube على الجهاز.");
            fallback.setVisibility(View.GONE);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (ready) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                player.seekTo(Math.max(0, player.getCurrentPosition() - 10000)); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                player.seekTo(Math.min(player.getDuration(), player.getCurrentPosition() + 10000)); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                if (player.isPlaying()) player.pause(); else player.start();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        disposed = true;
        ready = false;
        ui.removeCallbacksAndMessages(null);
        if (player != null) player.stopPlayback();
        network.shutdownNow();
        super.onDestroy();
    }
}
