package tv.streamtube.android;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

final class Style {
    static final int BACK = Color.rgb(10, 12, 18);
    static final int CARD = Color.rgb(26, 29, 39);
    static final int WHITE = Color.rgb(246, 247, 251);
    static final int MUTED = Color.rgb(159, 166, 182);
    static final int RED = Color.rgb(241, 59, 76);
    private Style() {}

    static int dp(Context c, int v) { return (int) (v*c.getResources().getDisplayMetrics().density + .5f); }
    static GradientDrawable rounded(int color, int radius, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(c, radius)); return d;
    }
    static StateListDrawable focused(Context c) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable highlight = rounded(RED, 13, c);
        s.addState(new int[] { android.R.attr.state_focused }, highlight);
        s.addState(new int[] { android.R.attr.state_pressed }, highlight);
        s.addState(new int[] {}, rounded(CARD, 13, c));
        return s;
    }
    static TextView text(Context c, String name, int size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(name);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    static TextView button(Context c, String label) {
        TextView t = text(c, label, 18, WHITE, true);
        t.setPadding(dp(c, 20), dp(c, 11), dp(c, 20), dp(c, 11));
        t.setBackground(focused(c));
        t.setFocusable(true);
        t.setClickable(true);
        t.setGravity(android.view.Gravity.CENTER);
        t.setOnFocusChangeListener((View v, boolean f) -> v.animate().scaleX(f ? 1.05f : 1f).scaleY(f ? 1.05f : 1f).setDuration(115).start());
        return t;
    }
}
