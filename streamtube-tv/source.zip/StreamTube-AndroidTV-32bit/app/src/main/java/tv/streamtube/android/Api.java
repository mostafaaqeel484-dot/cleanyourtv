package tv.streamtube.android;

import android.net.Uri;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Public Piped + Invidious APIs. Requests race across instances, rather than blocking on dead servers. */
final class Api {
    private static final String TAG = "StreamTubeTV";
    private static final String[][] SERVERS = {
        {"invidious", "https://inv.nadeko.net"},
        {"invidious", "https://invidious.tiekoetter.com"},
        {"invidious", "https://yt.chocolatemoo53.com"},
        {"invidious", "https://invidious.nerdvpn.de"},
        {"piped", "https://pipedapi.adminforge.de"},
        {"piped", "https://pipedapi.kavin.rocks"},
        {"piped", "https://pipedapi.tokhmi.xyz"}
    };
    private static volatile String chosen = "";
    private static volatile String lastError = "";
    private static volatile String customServer = "";

    private Api() {}

    static void setCustomServer(String input) {
        String s = input == null ? "" : input.trim();
        if (!s.isEmpty()) {
            Uri uri = Uri.parse(s);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                uri.getUserInfo() != null || uri.getPort() != -1 || uri.getQuery() != null ||
                uri.getFragment() != null) {
                throw new IllegalArgumentException("اكتب رابط HTTPS لخادم API فقط، بدون مسار أو معاملات");
            }
            s = "https://" + uri.getHost();
        }
        customServer = s;
    }
    static String customServer() { return customServer; }
    static String provider() { return chosen; }
    static String lastError() { return lastError; }

    static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Accept-Language", "ar,en-US;q=0.8,en;q=0.5");
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            c.setConnectTimeout(4900);
            c.setReadTimeout(8500);
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) != -1) {
                    out.write(b, 0, n);
                    if (out.size() > 3_000_000) throw new Exception("Response too large");
                }
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally { c.disconnect(); }
    }

    private static final class Server {
        final String type, host;
        Server(String type, String host) { this.type=type; this.host=host; }
    }

    private interface Parser<T> { T parse(Server server, String body) throws Exception; }
    private static List<Server> sources() {
        ArrayList<Server> list = new ArrayList<>();
        if (!customServer.isEmpty()) {
            String type = customServer.toLowerCase(Locale.ROOT).contains("piped") ? "piped" : "invidious";
            list.add(new Server(type, customServer));
        }
        for (String[] server : SERVERS) {
            if (!server[1].equals(customServer)) list.add(new Server(server[0], server[1]));
        }
        if (!chosen.isEmpty()) {
            for (int i=0; i<list.size(); i++) {
                if (list.get(i).host.equals(chosen)) { Collections.swap(list, 0, i); break; }
            }
        }
        return list;
    }

    private static <T> T tryServers(String pipedPath, String invidiousPath, Parser<T> parser) throws Exception {
        List<Server> hosts = sources();
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(6, hosts.size()));
        CompletionService<T> tasks = new ExecutorCompletionService<>(pool);
        List<String> problems = Collections.synchronizedList(new ArrayList<>());
        try {
            for (Server server : hosts) {
                tasks.submit(() -> {
                    String path = server.type.equals("piped") ? pipedPath : invidiousPath;
                    try {
                        T result = parser.parse(server, get(server.host + path));
                        chosen = server.host;
                        return result;
                    } catch (Exception e) {
                        String shortError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        problems.add(Uri.parse(server.host).getHost() + ": " + shortError);
                        Log.w(TAG, "Backend failed " + server.host + path, e);
                        throw e;
                    }
                });
            }
            long stop = System.nanoTime() + TimeUnit.SECONDS.toNanos(16);
            for (int completed=0; completed<hosts.size(); completed++) {
                long remaining = stop - System.nanoTime();
                if (remaining <= 0) break;
                Future<T> f = tasks.poll(remaining, TimeUnit.NANOSECONDS);
                if (f == null) break;
                try {
                    T output = f.get();
                    lastError = "";
                    return output;
                } catch (Exception ignored) { }
            }
            lastError = problems.isEmpty() ? "الاتصال بالخوادم انتهى وقته" : String.join(" | ", problems);
            throw new Exception("No available video backend: " + lastError);
        } finally { pool.shutdownNow(); }
    }

    static JSONArray trending() throws Exception {
        return tryServers("/trending?region=US", "/api/v1/trending?region=US", (host, body) -> {
            JSONArray result = normalize(host, new JSONArray(body));
            if (result.length() == 0) throw new Exception("Trending response empty");
            return result;
        });
    }

    static JSONArray search(String text) throws Exception {
        String q = Uri.encode(text);
        return tryServers("/search?q=" + q + "&filter=videos", "/api/v1/search?q=" + q + "&type=video", (host, body) -> {
            JSONArray data;
            if (host.type.equals("piped")) {
                JSONObject object = new JSONObject(body);
                if (object.has("error")) throw new Exception(object.optString("error"));
                data = object.optJSONArray("items");
                if (data == null) throw new Exception("Missing search items");
            } else data = new JSONArray(body);
            JSONArray result = normalize(host, data);
            if (result.length() == 0) throw new Exception("Empty search results");
            return result;
        });
    }

    static JSONObject streams(String id) throws Exception {
        if (id == null || !id.matches("[A-Za-z0-9_-]{11}")) throw new IllegalArgumentException("Invalid video ID");
        return tryServers("/streams/"+id, "/api/v1/videos/"+id, (server, body) -> {
            JSONObject data = new JSONObject(body);
            if (data.has("error")) throw new Exception(data.optString("error"));
            if (server.type.equals("piped")) {
                JSONArray arr = data.optJSONArray("videoStreams");
                if ((arr == null || arr.length() == 0) && data.optString("hls", "").isEmpty())
                    throw new Exception("No streams");
                return data;
            }
            JSONObject normalized = new JSONObject();
            JSONArray output = new JSONArray();
            JSONArray formatStreams = data.optJSONArray("formatStreams");
            if (formatStreams != null) for (int i=0; i<formatStreams.length(); i++) {
                JSONObject original = formatStreams.optJSONObject(i);
                if (original == null) continue;
                String url = original.optString("url", "");
                if (!url.startsWith("https://")) continue;
                String mime = original.optString("type", original.optString("container", ""));
                String quality = original.optString("qualityLabel", original.optString("quality", ""));
                int height = 0;
                try { height = Integer.parseInt(quality.replaceAll("[^0-9]", "")); }
                catch (Exception ignored) { }
                if (height == 0 && quality.contains("medium")) height = 360;
                if (height == 0 && quality.contains("small")) height = 240;
                JSONObject entry = new JSONObject();
                entry.put("url", url);
                entry.put("height", height);
                entry.put("mimeType", mime.contains("mp4") ? "video/mp4" : mime);
                entry.put("codec", "avc1");
                entry.put("videoOnly", false);
                output.put(entry);
            }
            normalized.put("videoStreams", output);
            normalized.put("hls", data.optString("hlsUrl", ""));
            if (output.length() == 0 && normalized.optString("hls").isEmpty())
                throw new Exception("No merged streams available");
            return normalized;
        });
    }

    private static JSONArray normalize(Server server, JSONArray data) throws Exception {
        JSONArray result = new JSONArray();
        for (int i=0; i<data.length(); i++) {
            JSONObject item = data.optJSONObject(i);
            if (item == null) continue;
            if (server.type.equals("invidious") && !"video".equals(item.optString("type", "video"))) continue;
            String id = item.optString("videoId", "");
            if (!id.matches("[A-Za-z0-9_-]{11}")) id = idFromUrl(item.optString("url", ""));
            if (id.isEmpty()) continue;
            JSONObject entry = new JSONObject();
            entry.put("videoId", id);
            entry.put("title", item.optString("title", "Video"));
            entry.put("uploaderName", item.optString("uploaderName", item.optString("author", "")));
            String thumb = item.optString("thumbnail", "");
            if (thumb.isEmpty()) {
                JSONArray thumbnails = item.optJSONArray("videoThumbnails");
                if (thumbnails != null && thumbnails.length() > 0) {
                    JSONObject t = thumbnails.optJSONObject(Math.min(2, thumbnails.length()-1));
                    if (t != null) thumb = t.optString("url", "");
                }
            }
            if (!thumb.startsWith("https://")) thumb = "https://i.ytimg.com/vi/"+id+"/hqdefault.jpg";
            entry.put("thumbnailUrl", thumb);
            result.put(entry);
        }
        return result;
    }

    static JSONArray sponsors(String videoId) {
        String url = "https://sponsor.ajay.app/api/skipSegments?videoID=" + Uri.encode(videoId)
            + "&categories=" + Uri.encode("[\"sponsor\"]");
        try { return new JSONArray(get(url)); }
        catch (Exception e) { return new JSONArray(); }
    }

    static String idFromUrl(String url) {
        if (url == null || url.isEmpty()) return "";
        Uri u = Uri.parse(url);
        String id = u.getQueryParameter("v");
        if (id == null && u.getPathSegments().size() > 0) id = u.getLastPathSegment();
        return id != null && id.matches("[A-Za-z0-9_-]{11}") ? id : "";
    }
}
