package tv.streamtube.android;

import android.net.Uri;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Small, dependency-free community API client. Public API instances are not guaranteed. */
final class Api {
    static final String[] INSTANCES = {
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.tokhmi.xyz",
        "https://pipedapi.adminforge.de"
    };
    private static volatile String preferred = INSTANCES[0];

    private Api() {}

    static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "StreamTubeTV-Android/0.1");
            c.setConnectTimeout(8500);
            c.setReadTimeout(13000);
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) != -1) {
                    out.write(b, 0, n);
                    if (out.size() > 2_500_000) throw new Exception("Response too large");
                }
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally { c.disconnect(); }
    }

    interface Parse<T> { T parse(String response) throws Exception; }

    static <T> T query(String path, Parse<T> parse) throws Exception {
        Exception last = null;
        String first = preferred;
        String[] choices = new String[INSTANCES.length + 1];
        choices[0] = first;
        System.arraycopy(INSTANCES, 0, choices, 1, INSTANCES.length);
        for (String host : choices) {
            if (host == null) continue;
            try {
                T output = parse.parse(get(host + path));
                preferred = host;
                return output;
            } catch (Exception ex) {
                Log.w("StreamTubeTV", "Piped instance failed: " + host, ex);
                last = ex;
            }
        }
        throw new Exception("No Piped API instance responded", last);
    }

    static JSONArray trending() throws Exception {
        return query("/trending?region=US", JSONArray::new);
    }

    static JSONArray search(String text) throws Exception {
        String query = Uri.encode(text);
        return query("/search?q=" + query + "&filter=videos", body -> {
            JSONObject object = new JSONObject(body);
            return object.optJSONArray("items") != null ? object.getJSONArray("items") : new JSONArray();
        });
    }

    static JSONObject streams(String videoId) throws Exception {
        if (!videoId.matches("[A-Za-z0-9_-]{11}")) throw new IllegalArgumentException("Invalid videoId");
        return query("/streams/" + videoId, JSONObject::new);
    }

    static JSONArray sponsors(String videoId) throws Exception {
        String url = "https://sponsor.ajay.app/api/skipSegments?videoID=" + Uri.encode(videoId)
            + "&categories=" + Uri.encode("[\"sponsor\"]");
        try { return new JSONArray(get(url)); }
        catch (Exception e) { return new JSONArray(); }
    }

    static String idFromUrl(String url) {
        if (url == null || url.isEmpty()) return "";
        Uri u = Uri.parse(url);
        String id = u.getQueryParameter("v");
        if (id == null && u.getPathSegments().size() > 0) {
            id = u.getLastPathSegment();
        }
        return id != null && id.matches("[A-Za-z0-9_-]{11}") ? id : "";
    }
}
